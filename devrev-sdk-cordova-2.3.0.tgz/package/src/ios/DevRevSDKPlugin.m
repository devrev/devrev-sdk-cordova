#import "DevRevSDKPlugin.h"
#import <DevRevSDK/DevRevSDK.h>

@implementation DevRevSDKPlugin

static NSString *const DRInvalidArgumentErrorMessage = @"Invalid argument";
static NSString *inAppLinkHandlerId;
static NSString *const DRFrameworkName = @"Cordova";

- (id)safeArgumentAtIndex:(NSUInteger)index fromCommand:(CDVInvokedUrlCommand *)command {
	if (command.arguments.count <= index || ![command.arguments objectAtIndex:index]) {
		return nil;
	}
	return [command.arguments objectAtIndex:index];
}

#pragma mark - Configuration

- (FeatureConfiguration *)featureConfigurationFromDictionary:(NSDictionary *)featureConfigDict {
	if (!featureConfigDict || ![featureConfigDict isKindOfClass:[NSDictionary class]]) {
		return nil;
	}
	NSNumber *enableFrameCapture = featureConfigDict[@"enableFrameCapture"];
	NSNumber *autoStartRecording = featureConfigDict[@"autoStartRecording"];
	NSNumber *alwaysUseRemoteConfig = featureConfigDict[@"alwaysUseRemoteConfig"];
	NSDictionary *supportWidgetThemeDict = featureConfigDict[@"supportWidgetTheme"];

	if (![enableFrameCapture isKindOfClass:[NSNumber class]] ||
	    ![autoStartRecording isKindOfClass:[NSNumber class]] ||
	    ![alwaysUseRemoteConfig isKindOfClass:[NSNumber class]] ||
	    ![supportWidgetThemeDict isKindOfClass:[NSDictionary class]]) {
		return nil;
	}

	NSNumber *prefersSystemTheme = supportWidgetThemeDict[@"prefersSystemTheme"];
	if (![prefersSystemTheme isKindOfClass:[NSNumber class]]) {
		return nil;
	}

	NSString *primaryTextColor = [supportWidgetThemeDict[@"primaryTextColor"] isKindOfClass:[NSString class]] ? supportWidgetThemeDict[@"primaryTextColor"] : nil;
	NSString *accentColor = [supportWidgetThemeDict[@"accentColor"] isKindOfClass:[NSString class]] ? supportWidgetThemeDict[@"accentColor"] : nil;
	NSDictionary *spacing = supportWidgetThemeDict[@"spacing"];
	NSMutableDictionary<NSString *, NSString *> *spacingDict = nil;
	if ([spacing isKindOfClass:[NSDictionary class]]) {
		spacingDict = [NSMutableDictionary dictionary];
		for (NSString *key in spacing) {
			id value = spacing[key];
			if ([value isKindOfClass:[NSString class]]) {
				spacingDict[key] = value;
			}
		}
	}

	SupportWidgetTheme *supportWidgetTheme = [[SupportWidgetTheme alloc] initWithPrefersSystemTheme:[prefersSystemTheme boolValue]
																				  primaryTextColor:primaryTextColor
																						accentColor:accentColor
																						  spacing:spacingDict];

	return [[FeatureConfiguration alloc] initWithEnableFrameCapture:[enableFrameCapture boolValue]
												autoStartRecording:[autoStartRecording boolValue]
											 alwaysUseRemoteConfig:[alwaysUseRemoteConfig boolValue]
												supportWidgetTheme:supportWidgetTheme
										 enableSupportChatStreaming:NO
								 supportWidgetArticleSearchFilters:nil];
}

- (void)configure:(CDVInvokedUrlCommand *)command {
	NSString *appID = [self safeArgumentAtIndex:0 fromCommand:command];
	NSString *frameworkVersion = [self safeArgumentAtIndex:1 fromCommand:command];
	NSDictionary *featureConfigDict = [self safeArgumentAtIndex:2 fromCommand:command];
	CDVPluginResult *result;

	if (!appID) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	FeatureConfiguration *featureConfig = [self featureConfigurationFromDictionary:featureConfigDict];
	if (featureConfig) {
		[DevRev configureWithAppID:appID featureConfiguration:featureConfig];
	} else {
		[DevRev configureWithAppID:appID];
	}
	[DevRev setAppFrameworkInfo:DRFrameworkName version:frameworkVersion];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

- (void)updateFeatureConfiguration:(CDVInvokedUrlCommand *)command {
	NSDictionary *featureConfigDict = [self safeArgumentAtIndex:0 fromCommand:command];
	CDVPluginResult *result;

	if (![featureConfigDict isKindOfClass:[NSDictionary class]]) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	FeatureConfiguration *featureConfig = [self featureConfigurationFromDictionary:featureConfigDict];
	if (!featureConfig) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	[DevRev updateFeatureConfiguration:featureConfig];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

#pragma mark - Identification

- (void)identifyUnverifiedUser:(CDVInvokedUrlCommand *)command {
	NSDictionary *identityDict = [self safeArgumentAtIndex:0 fromCommand:command];
	CDVPluginResult *result;

	if (![identityDict isKindOfClass:[NSDictionary class]]) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	NSString *userID = identityDict[@"userID"];
	if (![userID isKindOfClass:[NSString class]]) {
		userID = nil;
	}

	NSString *organizationID = identityDict[@"organizationID"];
	if (![organizationID isKindOfClass:[NSString class]]) {
		organizationID = nil;
	}

	NSString *accountID = identityDict[@"accountID"];
	if (![accountID isKindOfClass:[NSString class]]) {
		accountID = nil;
	}

	NSDictionary *userTraitsDict = identityDict[@"userTraits"];
	UserTraits *userTraits = nil;
	if ([userTraitsDict isKindOfClass:[NSDictionary class]]) {
		userTraits = [[UserTraits alloc] initWithDisplayName:userTraitsDict[@"displayName"]
													   email:userTraitsDict[@"email"]
													fullName:userTraitsDict[@"fullName"]
											 userDescription:userTraitsDict[@"description"]
												phoneNumbers:userTraitsDict[@"phoneNumbers"]
												customFields:userTraitsDict[@"customFields"]];
	}

	NSDictionary *orgTraitsDict = identityDict[@"organizationTraits"];
	OrganizationTraits *organizationTraits = nil;
	if ([orgTraitsDict isKindOfClass:[NSDictionary class]]) {
		organizationTraits = [[OrganizationTraits alloc] initWithDisplayName:orgTraitsDict[@"displayName"]
																	  domain:orgTraitsDict[@"domain"]
													 organizationDescription:orgTraitsDict[@"description"]
																phoneNumbers:orgTraitsDict[@"phoneNumbers"]
																		tier:orgTraitsDict[@"tier"]
																customFields:orgTraitsDict[@"customFields"]];
	}

	NSDictionary *accountTraitsDict = identityDict[@"accountTraits"];
	AccountTraits *accountTraits = nil;
	if ([accountTraitsDict isKindOfClass:[NSDictionary class]]) {
		accountTraits = [[AccountTraits alloc] initWithDisplayName:accountTraitsDict[@"displayName"]
														   domains:accountTraitsDict[@"domains"]
												accountDescription:accountTraitsDict[@"description"]
													  phoneNumbers:accountTraitsDict[@"phoneNumbers"]
														  websites:accountTraitsDict[@"websites"]
															  tier:accountTraitsDict[@"tier"]
													  customFields:accountTraitsDict[@"customFields"]];
	}

	Identity *identity = [[Identity alloc] initWithUserID:userID
										   organizationID:organizationID
												accountID:accountID
											   userTraits:userTraits
									   organizationTraits:organizationTraits
											accountTraits:accountTraits];
	[DevRev identifyUnverifiedUser:identity];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

- (void)identifyVerifiedUser:(CDVInvokedUrlCommand *)command {
	NSString *userID = [self safeArgumentAtIndex:0 fromCommand:command];
	NSString *sessionToken = [self safeArgumentAtIndex:1 fromCommand:command];
	CDVPluginResult *result;

	if (!userID || !sessionToken) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	[DevRev identifyVerifiedUser:userID sessionToken:sessionToken];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

- (void)identifyAnonymousUser:(CDVInvokedUrlCommand *)command {
	NSString *userID = [self safeArgumentAtIndex:0 fromCommand:command];
	CDVPluginResult *result;

	if (!userID) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	[DevRev identifyAnonymousUser:userID];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

- (void)updateUser:(CDVInvokedUrlCommand *)command {
	NSDictionary *identityDict = [self safeArgumentAtIndex:0 fromCommand:command];
	CDVPluginResult *result;

	if (![identityDict isKindOfClass:[NSDictionary class]]) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	NSString *userID = identityDict[@"userID"];
	if (![userID isKindOfClass:[NSString class]]) {
		userID = nil;
	}

	NSString *organizationID = identityDict[@"organizationID"];
	if (![organizationID isKindOfClass:[NSString class]]) {
		organizationID = nil;
	}

	NSString *accountID = identityDict[@"accountID"];
	if (![accountID isKindOfClass:[NSString class]]) {
		accountID = nil;
	}

	NSDictionary *userTraitsDict = identityDict[@"userTraits"];
	UserTraits *userTraits = nil;
	if ([userTraitsDict isKindOfClass:[NSDictionary class]]) {
		userTraits = [[UserTraits alloc] initWithDisplayName:userTraitsDict[@"displayName"]
													   email:userTraitsDict[@"email"]
													fullName:userTraitsDict[@"fullName"]
											 userDescription:userTraitsDict[@"description"]
												phoneNumbers:userTraitsDict[@"phoneNumbers"]
												customFields:userTraitsDict[@"customFields"]];
	}

	NSDictionary *orgTraitsDict = identityDict[@"organizationTraits"];
	OrganizationTraits *organizationTraits = nil;
	if ([orgTraitsDict isKindOfClass:[NSDictionary class]]) {
		organizationTraits = [[OrganizationTraits alloc] initWithDisplayName:orgTraitsDict[@"displayName"]
																	  domain:orgTraitsDict[@"domain"]
													 organizationDescription:orgTraitsDict[@"description"]
																phoneNumbers:orgTraitsDict[@"phoneNumbers"]
																		tier:orgTraitsDict[@"tier"]
																customFields:orgTraitsDict[@"customFields"]];
	}

	NSDictionary *accountTraitsDict = identityDict[@"accountTraits"];
	AccountTraits *accountTraits = nil;
	if ([accountTraitsDict isKindOfClass:[NSDictionary class]]) {
		accountTraits = [[AccountTraits alloc] initWithDisplayName:accountTraitsDict[@"displayName"]
														   domains:accountTraitsDict[@"domains"]
												accountDescription:accountTraitsDict[@"description"]
													  phoneNumbers:accountTraitsDict[@"phoneNumbers"]
														  websites:accountTraitsDict[@"websites"]
															  tier:accountTraitsDict[@"tier"]
													  customFields:accountTraitsDict[@"customFields"]];
	}

	Identity *identity = [[Identity alloc] initWithUserID:userID
										   organizationID:organizationID
												accountID:accountID
											   userTraits:userTraits
									   organizationTraits:organizationTraits
											accountTraits:accountTraits];
	[DevRev updateUserWithIdentity:identity];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

- (void)logout:(CDVInvokedUrlCommand *)command {
	NSString *deviceID = [self safeArgumentAtIndex:0 fromCommand:command];
	CDVPluginResult *result;

	if (!deviceID) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	[DevRev logoutWithDeviceID:deviceID];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

#pragma mark - Support

- (void)showSupport:(CDVInvokedUrlCommand *)command {
	[DevRev showSupport:YES];
	CDVPluginResult *result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

- (void)createSupportConversation:(CDVInvokedUrlCommand *)command {
	[DevRev createSupportConversation:YES];
	CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

#pragma mark - Analytics

- (void)trackEvent:(CDVInvokedUrlCommand *)command {
	NSString *name = [self safeArgumentAtIndex:0 fromCommand:command];
	NSDictionary *properties = [self safeArgumentAtIndex:1 fromCommand:command];
	CDVPluginResult *result;

	if (!name || !properties) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	[DevRev trackEventWithName:name properties:properties];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

- (void)captureError:(CDVInvokedUrlCommand *)command {
	NSString *error = [self safeArgumentAtIndex:0 fromCommand:command];
	NSString *stackTrace = [self safeArgumentAtIndex:1 fromCommand:command];
	NSString *tag = [self safeArgumentAtIndex:2 fromCommand:command];
	CDVPluginResult *result;

	if (!error) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObject:error forKey:NSLocalizedDescriptionKey];
	NSArray *callStackSymbols = [NSThread callStackSymbols];

	if (stackTrace && stackTrace.length > 0) {
		NSArray *stackTraceComponents = [stackTrace componentsSeparatedByString:@"\n"];
		NSPredicate *predicate = [NSPredicate predicateWithBlock:^BOOL(NSString *evaluatedObject, NSDictionary *bindings) {
			return [[evaluatedObject stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length] > 0;
		}];
		NSArray *stackTraceLines = [stackTraceComponents filteredArrayUsingPredicate:predicate];
		userInfo[@"NSCallStackSymbols"] = stackTraceLines;
	} else {
		userInfo[@"NSCallStackSymbols"] = callStackSymbols;
	}

	NSError *nsError = [NSError errorWithDomain:@"DevRevSDK" code:0 userInfo:userInfo];
	[DevRev captureError:nsError tag:tag ?: @""];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

#pragma mark - Session recording

- (void)startRecording:(CDVInvokedUrlCommand *)command {
	[DevRev startRecording];
	CDVPluginResult *result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

- (void)stopRecording:(CDVInvokedUrlCommand *)command {
	[DevRev stopRecording];
	CDVPluginResult *result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

- (void)pauseRecording:(CDVInvokedUrlCommand *)command {
	[DevRev pauseRecording];
	CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

- (void)resumeRecording:(CDVInvokedUrlCommand *)command {
	[DevRev resumeRecording];
	CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

- (void)processAllOnDemandSessions:(CDVInvokedUrlCommand *)command {
	[DevRev processAllOnDemandSessions];
	CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

#pragma mark - Monitoring control

- (void)resumeAllMonitoring:(CDVInvokedUrlCommand *)command {
	[DevRev resumeAllMonitoring];
	CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

- (void)stopAllMonitoring:(CDVInvokedUrlCommand *)command {
	[DevRev stopAllMonitoring];
	CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

#pragma mark - In-app link handling

- (void)setShouldDismissModalsOnOpenLink:(CDVInvokedUrlCommand *)command {
    NSNumber *shouldDismissModalsOnOpenLink = [self safeArgumentAtIndex:0 fromCommand:command];
    CDVPluginResult *result;

    if (![shouldDismissModalsOnOpenLink isKindOfClass:[NSNumber class]]) {
        result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
        [self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
        return;
    }

    [DevRev setShouldDismissModalsOnOpenLink:[shouldDismissModalsOnOpenLink boolValue]];
    result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
    [self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

- (void)setInAppLinkHandler:(CDVInvokedUrlCommand *)command {
	inAppLinkHandlerId = command.callbackId;
	CDVPluginResult *pluginResult;

	if (!inAppLinkHandlerId) {
		pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:@"Failed to set in-app link handler"];
		[self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
	}

	[DevRev setInAppLinkHandler:^(NSURL *url) {
		[self sendInAppLinkHandlerWithURL:url];
	}];

	pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[pluginResult setKeepCallbackAsBool:YES];
	[self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

- (void)sendInAppLinkHandlerWithURL:(NSURL *)url {
	if (inAppLinkHandlerId) {
		NSDictionary *response = @{@"url": url.absoluteString};
		CDVPluginResult *pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:response];
		[self.commandDelegate sendPluginResult:pluginResult callbackId:inAppLinkHandlerId];
	}
}

#pragma mark - Session properties

- (void)addSessionProperties:(CDVInvokedUrlCommand *)command {
	NSDictionary *properties = [self safeArgumentAtIndex:0 fromCommand:command];
	CDVPluginResult *result;

	if (!properties) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	[DevRev addSessionProperties:properties];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

- (void)clearSessionProperties:(CDVInvokedUrlCommand *)command {
	[DevRev clearSessionProperties];
	CDVPluginResult *result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

#pragma mark - Timer Control

- (void)startTimer:(CDVInvokedUrlCommand *)command {
	NSString *name = [self safeArgumentAtIndex:0 fromCommand:command];
	NSDictionary *properties = [self safeArgumentAtIndex:1 fromCommand:command];
	CDVPluginResult *result;

	if (!name || !properties) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	[DevRev startTimerWithName:name properties:properties];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

- (void)endTimer:(CDVInvokedUrlCommand *)command {
	NSString *name = [self safeArgumentAtIndex:0 fromCommand:command];
	NSDictionary *properties = [self safeArgumentAtIndex:1 fromCommand:command];
	CDVPluginResult *result;

	if (!name || !properties) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	[DevRev endTimerWithName:name properties:properties];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

#pragma mark - Push Notifications

- (void)registerDeviceToken:(CDVInvokedUrlCommand *)command {
	NSString *deviceToken = [self safeArgumentAtIndex:0 fromCommand:command];
	NSString *deviceID = [self safeArgumentAtIndex:1 fromCommand:command];
	CDVPluginResult *result;

	if (!deviceToken && !deviceID) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	[DevRev registerDeviceToken:deviceToken forDeviceID:deviceID];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

- (void)unregisterDevice:(CDVInvokedUrlCommand *)command {
	NSString *deviceID = [self safeArgumentAtIndex:0 fromCommand:command];
	CDVPluginResult *pluginResult;

	if (!deviceID) {
		pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
		return;
	}

	[DevRev unregisterDeviceWithID:deviceID];
	pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

- (void)processPushNotification:(CDVInvokedUrlCommand *)command {
	NSString *payload = [self safeArgumentAtIndex:0 fromCommand:command];
	CDVPluginResult *result;

	if (!payload) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	[DevRev processPushNotification:payload];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

#pragma mark - Screen tracking

- (void)trackScreenName:(CDVInvokedUrlCommand *)command {
	NSString *screenName = [self safeArgumentAtIndex:0 fromCommand:command];
	CDVPluginResult *pluginResult;

	if (!screenName) {
		pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
		return;
	}

	[DevRev trackScreenWithName:screenName];
	pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

#pragma mark - Dynamic theme configuration

- (void)setPrefersSystemTheme:(CDVInvokedUrlCommand *)command {
	NSNumber *prefersSystemTheme = [self safeArgumentAtIndex:0 fromCommand:command];
	CDVPluginResult *result;

	if (![prefersSystemTheme isKindOfClass:[NSNumber class]]) {
		result = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:DRInvalidArgumentErrorMessage];
		[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
		return;
	}

	[DevRev setPrefersSystemTheme:[prefersSystemTheme boolValue]];
	result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

#pragma mark - User interaction tracking

- (void)pauseUserInteractionTracking:(CDVInvokedUrlCommand *)command {
	[DevRev pauseUserInteractionTracking];
	CDVPluginResult *result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

- (void)resumeUserInteractionTracking:(CDVInvokedUrlCommand *)command {
	[DevRev resumeUserInteractionTracking];
	CDVPluginResult *result = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK];
	[self.commandDelegate sendPluginResult:result callbackId:command.callbackId];
}

@end
