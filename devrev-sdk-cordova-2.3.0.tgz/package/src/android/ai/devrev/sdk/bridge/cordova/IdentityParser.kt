package ai.devrev.sdk.bridge.cordova

import ai.devrev.sdk.model.Identity
import ai.devrev.sdk.model.UserInfo
import ai.devrev.sdk.model.OrganizationInfo
import ai.devrev.sdk.model.AccountInfo
import org.json.JSONObject
import org.json.JSONArray
import org.json.JSONException

object IdentityParser {
    @Throws(JSONException::class)
    fun parseIdentity(map: JSONObject): Identity {
        return Identity(
            map.optString("userID", ""),
            map.optStringOrNull("organizationID"),
            map.optStringOrNull("accountID"),
            map.optJSONObjectOrNull("userTraits")?.let { parseUserTraits(it) },
            map.optJSONObjectOrNull("organizationTraits")?.let { parseOrganizationTraits(it) },
            map.optJSONObjectOrNull("accountTraits")?.let { parseAccountTraits(it) }
        )
    }

    @Throws(JSONException::class)
    private fun parseUserTraits(map: JSONObject): UserInfo {
        return UserInfo(
            map.optStringOrNull("displayName"),
            map.optStringOrNull("email"),
            map.optStringOrNull("fullName"),
            map.optStringOrNull("description"),
            map.optJSONArrayOrNull("phoneNumbers")?.let { toStringList(it) },
            map.optJSONObjectOrNull("customFields")?.let { toStringMap(it) }
        )
    }

    @Throws(JSONException::class)
    private fun parseOrganizationTraits(map: JSONObject): OrganizationInfo {
        return OrganizationInfo(
            map.optStringOrNull("displayName"),
            map.optStringOrNull("domain"),
            map.optStringOrNull("description"),
            map.optJSONArrayOrNull("phoneNumbers")?.let { toStringList(it) },
            map.optStringOrNull("tier"),
            map.optJSONObjectOrNull("customFields")?.let { toStringMap(it) }
        )
    }

    @Throws(JSONException::class)
    private fun parseAccountTraits(map: JSONObject): AccountInfo {
        return AccountInfo(
            map.optStringOrNull("displayName"),
            map.optJSONArrayOrNull("domains")?.let { toStringList(it) },
            map.optStringOrNull("description"),
            map.optJSONArrayOrNull("phoneNumbers")?.let { toStringList(it) },
            map.optJSONArrayOrNull("websites")?.let { toStringList(it) },
            map.optStringOrNull("tier"),
            map.optJSONObjectOrNull("customFields")?.let { toStringMap(it) }
        )
    }

    private fun JSONObject.optStringOrNull(key: String): String? {
        return if (this.has(key)) this.optString(key) else null
    }

    private fun JSONObject.optJSONArrayOrNull(key: String): JSONArray? {
        return if (this.has(key)) this.getJSONArray(key) else null
    }

    private fun JSONObject.optJSONObjectOrNull(key: String): JSONObject? {
        return if (this.has(key)) this.getJSONObject(key) else null
    }

    @Throws(JSONException::class)
    private fun toStringList(array: JSONArray?): List<String>? {
        val list = mutableListOf<String>()
        if (array != null) {
            for (i in 0 until array.length()) {
                list.add(array.getString(i))
            }
        }
        return if (list.isEmpty()) null else list
    }

    @Throws(JSONException::class)
    private fun toStringMap(map: JSONObject?): Map<String, String>? {
        val result = mutableMapOf<String, String>()
        if (map != null) {
            val keys = map.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = map.get(key)
                when (value) {
                    is String, is Number, is Boolean -> result[key] = value.toString()
                    is JSONObject -> result.putAll(toStringMap(value) ?: emptyMap())
                }
            }
        }
        return if (result.isEmpty()) null else result
    }
}
