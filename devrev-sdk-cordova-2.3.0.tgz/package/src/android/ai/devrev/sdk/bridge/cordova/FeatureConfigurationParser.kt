package ai.devrev.sdk.bridge.cordova

import ai.devrev.sdk.model.FeatureConfiguration
import ai.devrev.sdk.model.SupportWidgetTheme
import org.json.JSONObject
import org.json.JSONException

object FeatureConfigurationParser {
    @Throws(JSONException::class)
    fun parseFeatureConfiguration(map: JSONObject?): FeatureConfiguration {
        if (map == null) {
            throw JSONException("Feature configuration is required")
        }

        val enableFrameCapture = map.getBoolean("enableFrameCapture")
        val autoStartRecording = map.getBoolean("autoStartRecording")
        val prefersDialogMode = map.getBoolean("prefersDialogMode")
        val alwaysUseRemoteConfig = map.getBoolean("alwaysUseRemoteConfig")
        val supportWidgetThemeJSON = map.getJSONObject("supportWidgetTheme")
        val supportWidgetTheme = parseSupportWidgetTheme(supportWidgetThemeJSON)

        return FeatureConfiguration(
            enableFrameCapture = enableFrameCapture,
            autoStartRecording = autoStartRecording,
            prefersDialogMode = prefersDialogMode,
            alwaysUseRemoteConfig = alwaysUseRemoteConfig,
            supportWidgetTheme = supportWidgetTheme
        )
    }

    private fun parseSupportWidgetTheme(map: JSONObject?): SupportWidgetTheme {
        if (map == null) {
            throw JSONException("supportWidgetTheme is required")
        }
        val prefersSystemTheme = map.getBoolean("prefersSystemTheme")
        val primaryTextColor = map.optString("primaryTextColor", null)
        val accentColor = map.optString("accentColor", null)
        val spacingJSON = map.optJSONObject("spacing")
        val spacing: Map<String, String>? = if (spacingJSON != null) {
            val spacingMap = mutableMapOf<String, String>()
            val keys = spacingJSON.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = spacingJSON.optString(key, null)
                if (value != null) {
                    spacingMap[key] = value
                }
            }
            if (spacingMap.isNotEmpty()) spacingMap else null
        } else {
            null
        }
        return SupportWidgetTheme(
            prefersSystemTheme = prefersSystemTheme,
            primaryTextColor = primaryTextColor,
            accentColor = accentColor,
            spacing = spacing
        )
    }
}
