package ai.devrev.sdk.bridge.cordova

enum class Method(val methodName: String) {
    // Configuration
    CONFIGURE("configure"),
    UPDATE_FEATURE_CONFIGURATION("updateFeatureConfiguration"),

    // Identification
    IDENTIFY_UNVERIFIED_USER("identifyUnverifiedUser"),
    IDENTIFY_VERIFIED_USER("identifyVerifiedUser"),
    IDENTIFY_ANONYMOUS_USER("identifyAnonymousUser"),
    UPDATE_USER("updateUser"),
    LOGOUT("logout"),

    // Support
    SHOW_SUPPORT("showSupport"),
    CREATE_SUPPORT_CONVERSATION("createSupportConversation"),

    // Analytics
    TRACK_EVENT("trackEvent"),
    CAPTURE_ERROR("captureError"),

    // Session recording
    START_RECORDING("startRecording"),
    STOP_RECORDING("stopRecording"),
    PAUSE_RECORDING("pauseRecording"),
    RESUME_RECORDING("resumeRecording"),
    PROCESS_ALL_ON_DEMAND_SESSION("processAllOnDemandSessions"),

    // Session properties
    ADD_SESSION_PROPERTIES("addSessionProperties"),
    CLEAR_SESSION_PROPERTIES("clearSessionProperties"),

    // Timer control
    START_TIMER("startTimer"),
    END_TIMER("endTimer"),

    // Monitoring control
    RESUME_ALL_MONITORING("resumeAllMonitoring"),
    STOP_ALL_MONITORING("stopAllMonitoring"),

    // In-app link handling
    SET_IN_APP_LINK_HANDLER("setInAppLinkHandler"),
    SET_SHOULD_DISMISS_MODALS_ON_OPEN_LINK("setShouldDismissModalsOnOpenLink"),

    // Screen tracking
    TRACK_SCREEN_NAME("trackScreenName"),

    // Screen transition
    SET_IN_SCREEN_TRANSITIONING("setInScreenTransitioning"),

    // Dynamic theme configuration
    SET_PREFERS_SYSTEM_THEME("setPrefersSystemTheme"),

    // Push notifications
    REGISTER_DEVICE_TOKEN("registerDeviceToken"),
    UNREGISTER_DEVICE("unregisterDevice"),
    PROCESS_PUSH_NOTIFICATION("processPushNotification"),

    // User interaction tracking
    PAUSE_USER_INTERACTION_TRACKING("pauseUserInteractionTracking"),
    RESUME_USER_INTERACTION_TRACKING("resumeUserInteractionTracking");

    // Method resolution

    companion object {
        private val METHOD_MAP = values().associateBy(Method::methodName)

        fun getMethod(methodName: String): Method? {
            return METHOD_MAP[methodName]
        }
    }
}
